# import pandas as pd
# import plotly.express as px
# from dash import Dash, dcc, html
# from dash.dependencies import Input, Output
# from ..data.loader import DataSchema   

# from . import ids

# def render(app: Dash, data: pd.DataFrame) -> html.Div:
#     @app.callback(
#         Output(ids.LINE_CHART, "children"),
#         Input(ids.CHANNEL_DROPDOWN, "value")
#     )
#     def update_bar_chart(channels: list[str]) -> html.Div:
#         # if 'channel' not in data.columns:
#         #     return html.Div("No 'channel' column found in the data.", id=ids.BAR_CHART_DISCRETE)
        
#         filtered_data = data[data[DataSchema.CHANNEL].isin(channels)]
#         # filtered_data = data[data['date'].isin(dates)]

#         if filtered_data.shape[0] == 0:
#             return html.Div("No data selected.", id=ids.LINE_CHART)

#         def create_pivot_table() -> pd.DataFrame:
#             pt = filtered_data.pivot_table(
#                 values=DataSchema.SUBSCRIBER,
#                 index=DataSchema.CHANNEL,
#                 aggfunc="sum",
#                 fill_value=0
#             )
#             return pt.reset_index()

#         fig = px.line(
#             #  create_pivot_table(),
#             filtered_data,
#             x=DataSchema.CHANNEL,
#             y=DataSchema.SUBSCRIBER,
#             title="No.of subscriber count"
  
            
#         )

#         return html.Div([
#             # html.H1("Subscriber count based on channels"),
#                          dcc.Graph(figure=fig)], id=ids.LINE_CHART)

#     return html.Div(id=ids.LINE_CHART)
