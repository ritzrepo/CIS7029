import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html
from dash.dependencies import Input, Output
from ..data.loader import DataSchema
from . import ids

def render(app: Dash, data: pd.DataFrame) -> html.Div:
    @app.callback(
        Output(ids.BAR_CHART, "children"),
        Input(ids.CHANNEL_DROPDOWN, "value")
    )
    def update_bar_chart(channels: list) -> html.Div:
        if not channels:
            return html.Div("No data selected.", id=ids.BAR_CHART)

        filtered_data = data[data[DataSchema.CHANNEL].isin(channels)]

        if filtered_data.empty:
            return html.Div("No data selected.", id=ids.BAR_CHART)

        def create_pivot_table(data_column: str, title: str):
            pt = filtered_data.pivot_table(
                values=[data_column],
                index=[DataSchema.CHANNEL],
                aggfunc="max",
                fill_value=0
            )
            pt.reset_index(inplace=True)
            fig = px.bar(
                pt,
                x=DataSchema.CHANNEL,
                y=data_column,
                color=DataSchema.CHANNEL,
                title=title
            )
            return fig

        fig_video = create_pivot_table(DataSchema.VIDEO, "Latest Video Count")
        fig_sub = create_pivot_table(DataSchema.SUBSCRIBER, "Latest Subscriber Count")

        return html.Div([
            dcc.Graph(figure=fig_video, className="fig_video columns"),
            dcc.Graph(figure=fig_sub, className="fig_sub columns"),
        ], id=ids.BAR_CHART, style={'display': 'flex', 'flex-wrap': 'wrap', 'height': '600px'})

    return html.Div(id=ids.BAR_CHART)
