import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html
from dash.dependencies import Input, Output
from ..data.loader import DataSchema   

from . import ids

def render(app: Dash, data: pd.DataFrame) -> html.Div:
    @app.callback(
        Output(ids.LINE_CHART, "children"),
        Input(ids.CHANNEL_DROPDOWN, "value")
    )
    def update_bar_chart(channels: list[str]) -> html.Div:
        # if 'channel' not in data.columns:
        #     return html.Div("No 'channel' column found in the data.", id=ids.BAR_CHART_DISCRETE)
        
        filtered_data = data[data[DataSchema.CHANNEL].isin(channels)]
        # filtered_data = data[data['date'].isin(dates)]

        if filtered_data.shape[0] == 0:
            return html.Div("No data selected.", id=ids.LINE_CHART)

        def create_pivot_table(data_column: str, title: str) -> pd.DataFrame:
            pt = filtered_data.pivot_table(
                values=[data_column],
                index=DataSchema.CHANNEL,
                aggfunc="max",
                fill_value=0
            )
            pt.reset_index(inplace=True)
            fig = px.line(
                #  create_pivot_table(),
                filtered_data,
                x=DataSchema.CHANNEL,
                y=data_column,
                title=title
                 
            )
            return fig
        
        
        # fig_video = create_pivot_table(DataSchema.VIDEO, "Latest Video Count")
        fig_view = create_pivot_table(DataSchema.VIEW, "Latest View Count")
        # fig_sub = create_pivot_table(DataSchema.SUBSCRIBER, "Latest subscriber Count")
        # return html.Div([
        #     # html.H1("Subscriber count based on channels"),
        #                  dcc.Graph(figure=fig_subscriber)], id=ids.LINE_CHART)
    
        return html.Div([
                    # html.H1("Channel Analysis:2"),
                    html.Div([
                        # html.Div([
                        #     dcc.Graph(figure=fig_video)
                        # ], className="fig_video columns"),
                        html.Div([
                            dcc.Graph(figure=fig_view)
                        ], className="fig_view columns"),
                        # html.Div([
                        #     dcc.Graph(figure=fig_sub)
                        # ], className="fig_sub columns")
                    ], className="row")
                ], id=ids.LINE_CHART)


    return html.Div(id=ids.LINE_CHART)
