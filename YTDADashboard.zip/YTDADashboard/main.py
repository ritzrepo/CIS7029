from dash import Dash, html 
from dash_bootstrap_components.themes import BOOTSTRAP
from src.layout  import create_layout
from src.data.loader import load_channelstats_data,load_channelvideostats_data,load_instagram_stats_data,load_Video_channel_Comment_data
# import string

CHANNEL_FILE ='channelstats.csv'
VIDEO_FILE ='videostats.csv'
INSTAGRAM_FILE ='InstragramStats.csv'
CV_COMMENTVIDEO_FILE ='video_channel_comment.csv'
DATA_PATH ='./data/'

CHANNEL_DATA_PATH=f"{DATA_PATH}{CHANNEL_FILE}"
VIDEO_DATA_PATH=f"{DATA_PATH}{VIDEO_FILE}"
INSTAGRAM_DATA_PATH=f"{DATA_PATH}{INSTAGRAM_FILE}"
CV_COMMENTVIDEO_DATA_PATH=f"{DATA_PATH}{CV_COMMENTVIDEO_FILE}"
def main() -> None:
    chstatdata = load_channelstats_data(CHANNEL_DATA_PATH)
    channelvideodata = load_channelvideostats_data(VIDEO_DATA_PATH)
    instragramvideodata = load_instagram_stats_data(INSTAGRAM_DATA_PATH)
     #the below line disable to test without comment data
    # Video_channel_Comment_data = load_Video_channel_Comment_data(CV_COMMENTVIDEO_DATA_PATH)
    app = Dash(external_stylesheets=[BOOTSTRAP] )

    # Enabling debug mode
    app.debug = True

    app.title = "Dashboard for Socialmedia Analysis-CIS7029-20285863-Q2"
    #the below line disable to test without comment data
    # app.layout = create_layout(app,chstatdata,channelvideodata ,instragramvideodata,Video_channel_Comment_data)
    app.layout = create_layout(app,chstatdata,channelvideodata ,instragramvideodata )
    app.run(debug=True)


if __name__ == "__main__":
    main()