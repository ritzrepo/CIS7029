import pandas as pd
from dash import Dash, html
# from .data.loader import DataSchema,VideoDataSchema
from src.components import (
    date_dropdown,
    channel_dropdown,
    video_dropdown,
    month_dropdown,
    year_dropdown,
    bar_chart,
    instagram_bar_chart,
    line_chart,
    channel_bar_chart ,
    scatter_chart,

    pie_chart,
    # video_bar_chart,
    video_time_chart,
    video_scatter_chart,
    cv_comment_video_time_chart,
    cv_comment_video_table,
)
# def create_layout(app: Dash, data: pd.DataFrame, videodata: pd.DataFrame, instagramdata : pd.DataFrame,ch_comment_videodata : pd.DataFrame,) -> html.Div:
def create_layout(app: Dash, data: pd.DataFrame, videodata: pd.DataFrame, instagramdata : pd.DataFrame ) -> html.Div:
    return html.Div(
        className="app-div",
        children=[
            html.H1(app.title),
            html.Hr(),
            html.Div(
                className="dropdown-container",
                children=[
                    channel_dropdown.render(app, data) 
                    # video_dropdown.render(app, videodata),
                    # date_dropdown.render(app, data),
                    # year_dropdown.render(app, data),
                    # month_dropdown.render(app, data),
                ],
            ),
            html.Hr(),
            html.H1("Channel Analysis"),
            html.Hr(),
            html.Div(
                className="flex-container",
                children=[
                    html.Div(
                        className="bar-charts-container",
                        children=[
                            bar_chart.render(app, data ),
                            pie_chart.render(app, data),
                            instagram_bar_chart.render(app,instagramdata)
                            
                             
                        ],
                        style={'flex': 1},
                    ),
                ],
                style={'display': 'flex', 'flex-wrap': 'wrap'},
                # , 'width': '100%'
            ),
 
            html.Div(
                className="channelnonflex-container",
                children=[
                    line_chart.render(app, data ),
                    scatter_chart.render(app, data),
                ],
            ),
            html.Div(className="spacing-div", style={'height': '20px'}),
            html.Hr(),
            html.H1("Video Analysis"),
            html.Hr(),
            html.Div(
                className="video-flex-container",
                children=[
                    html.Div(
                        className="video-bar-charts-container",
                        children=[
                            # video_bar_chart.render(app, videodata),
                            video_time_chart.render(app, videodata),
                        ],
                        style={'flex': 1},
                    ),
                ],
                style={'display': 'flex', 'flex-wrap': 'wrap'},
                # , 'width': '100%'
            ),
            html.Div(
                className="video-channelnonflex-container",
                children=[
                   
                    video_scatter_chart.render(app, videodata),
                ],
            ),
            html.Div(className="spacing-div", style={'height': '20px'}),
            html.Hr(),
            html.H1("Video comments Analysis"),
            html.H5("Video comments - deactivated due to the PC performance."),
            html.Hr(),
            html.Div(
                className="videocomments-flex-container",
                children=[
                    html.Div(
                        className="videocomments-bar-charts-container",
                        children=[
                            #the below line disable to test without comment data
                            #  cv_comment_video_table.render(app, ch_comment_videodata),
                            #the below line disable to test without comment data
                            # cv_comment_video_time_chart.render(app, ch_comment_videodata),
                        ],
                        style={'flex': 1},
                    ),
                ],
                style={'display': 'flex', 'flex-wrap': 'wrap'},
                # , 'width': '100%'
            ),
            # html.Div(
            #     className="videocomments-channelnonflex-container",
            #     children=[
                   
            #         # video_scatter_chart.render(app, videodata),
            #     ],
            # ),
        ],
    )
