 Installation  steps
* Install virtual environment
    py -m venv myvenv
* Activate the environment
    myvenv\script\activate
* install requirements from an existing steps
    pip install -r .\environment\requirements.txt
    python.exe -m pip install --upgrade pip
    pip install -r .\environment\requirements-dev.txt

